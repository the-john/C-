#ifndef PRINT_H
#define PRINT_H

#include <iostream>
#include <vector>

void print_vector_float(std::vector< std::vector <float> > grid);
void print_vector_char(std::vector< std::vector <char> > grid);

#endif /* PRINT.H */
