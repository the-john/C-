#ifndef BLUR_IMPROVED_H
#define BLUR_IMPROVED_H

#include <vector>
#include <iostream>

std::vector < std::vector <float> > blur_improved(std::vector < std::vector < float> > &grid);

#endif /* BLUR_IMPROVED.H */