#ifndef INITIALIZE_BELIEFS_IMPROVED_H
#define INITIALIZE_BELIEFS_IMPROVED_H

#include <vector>

std::vector< std::vector <float> > initialize_beliefs_improved(int height, int width);

#endif /* INITIALIZE_BELIEFS_IMPROVED.H */
